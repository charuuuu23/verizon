package automation.verizon_jenkins;

import org.testng.annotations.Test;

public class MobileTest {
    @Test
	void login()
	{
		System.out.println("Login");
	}
    @Test
    void logout()
	{
		System.out.println("Logout");
		//int num=10/0;
	}
    
}
