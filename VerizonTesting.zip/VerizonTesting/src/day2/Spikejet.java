package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Spikejet {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.spicejet.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@data-testid='to-testID-origin']")).click();
		Thread.sleep(3000);
		
		  driver.findElement(By.xpath(
		  "//*[@id=\"main-container\"]/div/div[1]/div[3]/div[2]/div[3]/div/div[1]/div[1]/div[2]/input")).sendKeys("Mumbai(BOM)"); 
		  Thread.sleep(3000);
		  
		  
		  driver.findElement(By.xpath("//*[text()='KNU']")).click(); 
				  
	}
}
