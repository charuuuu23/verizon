package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.sun.tools.javac.util.List;

public class TutorialsPoint {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.tutorialspoint.com/index.htm");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		WebElement footer=driver.findElement(By.tagName("footer"));
		java.util.List<WebElement>links=footer.findElements(By.tagName("a"));
		System.out.println(links.size());
        for(WebElement e:links)
        {
        	System.out.println(e.getText());
        }
		
	//	System.out.println(foot.getSize());
		//System.out.println(foot.getLocation());	
	}
}
