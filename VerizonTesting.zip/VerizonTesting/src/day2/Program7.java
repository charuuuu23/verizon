package day2;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program7 {

	public static void main(String[] args) throws MalformedURLException, IOException, InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.tutorialspoint.com/index.htm");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement footer=driver.findElement(By.tagName("footer"));
		List<WebElement>links=footer.findElements(By.tagName("a"));
		
        for(WebElement e:links)
        {
        	System.out.print(e.getText() + " ");
        	HttpURLConnection conn=(HttpURLConnection)new URL(e.getAttribute("href")).openConnection();
    		conn.setRequestMethod("GET");
    		conn.connect();
        	if(conn.getResponseCode()==200)
		{
			System.out.println("Working");
		}
		else
		{
			System.out.println("Not Working");
		}
        }
	}

}
