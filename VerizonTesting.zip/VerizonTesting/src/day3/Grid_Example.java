package day3;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class Grid_Example {

	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub

		
		
		String baseURL = "https://www.geeksforgeeks.org/";
		String nodeURL = "http://localhost:4444/wd/hub";
		DesiredCapabilities capability =new DesiredCapabilities();
		capability.setBrowserName("chrome");
		capability.setPlatform(Platform.WINDOWS);
		WebDriver driver = new RemoteWebDriver(new URL(nodeURL),capability);
		driver.get(baseURL);


		
		
		
		
		
		
		
		
		
	}

}
