package Day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program1_Basic {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
WebDriver driver =new ChromeDriver();
driver.navigate().to("https://www.geeksforgeeks.org/");
	}

}
