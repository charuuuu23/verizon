package Day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://itera-qa.azurewebsites.net/home/automation");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.id("name")).sendKeys("Selenium");
		Thread.sleep(3000);
		driver.findElement(By.id("phone")).sendKeys("1234567890");
		Thread.sleep(3000);
		driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
		Thread.sleep(3000);
		driver.findElement(By.id("password")).sendKeys("123456");
		Thread.sleep(3000);
		driver.findElement(By.id("address")).sendKeys("Verizon,Chennai");
		Thread.sleep(3000);
		driver.findElement(By.id("male")).click();
		Thread.sleep(3000);
		String a[] ={"Monday","Wednesday","Friday","Sunday"};
		List<WebElement>tags=driver.findElements(By.tagName("input"));
		for(int index=0;index<tags.size();index++) {
			{
				if(index==8 || index==10 || index==12|| index==14)
				{
					tags.get(index).click();
					if(index==14)
						break;
					}
			}
	}
	}

}
