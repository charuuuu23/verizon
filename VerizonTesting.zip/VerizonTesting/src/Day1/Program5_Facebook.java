package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program5_Facebook {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.facebook.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement emailBox=driver.findElement(By.id("email"));
		emailBox.sendKeys("abc@gmail.com");
		Thread.sleep(3000);
		WebElement webelement=driver.findElement(By.id("pass"));
		webelement.sendKeys("123456");
		Thread.sleep(3000);
		WebElement logs=driver.findElement(By.name("login"));
		logs.click();		
	}

}
