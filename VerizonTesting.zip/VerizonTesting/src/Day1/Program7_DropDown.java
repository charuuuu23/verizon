package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Program7_DropDown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://itera-qa.azurewebsites.net/home/automation");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement country=driver.findElement(By.className("custom-select"));
		Select obj=new Select(country);
        obj.selectByIndex(6);	
        Thread.sleep(3000);
		obj.selectByVisibleText("Sweden");
		Thread.sleep(3000);
		obj.selectByValue("10");
		
	}

}
