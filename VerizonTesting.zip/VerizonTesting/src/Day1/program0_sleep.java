package Day1;

public class program0_sleep {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
System.out.println("One");
Thread.sleep(3000);
System.out.println("Two");
Thread.sleep(3000);
System.out.println("Three");
Thread.sleep(3000);
System.out.println("Four");
Thread.sleep(3000);
System.out.println("Five");
Thread.sleep(3000);

	}

}
