package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class BloggingTest {
@Test
	void method1() throws InterruptedException
	{
	System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
	WebDriver driver =new ChromeDriver();
	Thread.sleep(3000);
	driver.navigate().to("https://www.geeksforgeeks.org/");
	Thread.sleep(3000);
	driver.manage().window().maximize();
	Thread.sleep(3000);
	driver.close();
	}
@Test
void method2() throws InterruptedException
{
System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
WebDriver driver =new ChromeDriver();
Thread.sleep(3000);
driver.navigate().to("https://www.guru99.com/");
Thread.sleep(3000);
driver.manage().window().maximize();
Thread.sleep(3000);
driver.close();
}
@Test
void method3() throws InterruptedException
{
System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
WebDriver driver =new ChromeDriver();
Thread.sleep(3000);
driver.navigate().to("https://www.w3schools.com/");
Thread.sleep(3000);
driver.manage().window().maximize();
Thread.sleep(3000);
driver.close();
}
	
	
	
}
