package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Selenium_Test {
	
	WebDriver driver;
	
	@BeforeMethod
	void setup() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
		driver=new ChromeDriver();
		Thread.sleep(3000);
	}
	
	@Test
	void testcase() throws InterruptedException
	{
	driver.navigate().to("https://www.geeksforgeeks.org/");
	Thread.sleep(3000);
	driver.manage().window().maximize();
	Thread.sleep(3000);
	}
	
	@AfterMethod
	void teardown()
	{
		driver.close();
	}
	
	
	
	
}
