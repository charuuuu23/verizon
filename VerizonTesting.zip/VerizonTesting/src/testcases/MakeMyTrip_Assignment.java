package testcases;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MakeMyTrip_Assignment {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Day 2 Testing\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Thread.sleep(3000);
		driver.navigate().to("https://www.makemytrip.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.id("username")).sendKeys("6374690593");
		driver.findElement(By.xpath("//*[text()='Continue']")).click();
		Thread.sleep(3000);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Otp:");
		String str=sc.nextLine();
		driver.findElement(By.xpath("//*[@id='otp']"));
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("document.elementFromPoint(0,0).click()");
	}

}
