package testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class WebsiteTest {
	@BeforeSuite
	void beforesuite()
	{
		System.out.println("Before Suite");
	}
	@AfterSuite
	void aftersuite()
	{
		System.out.println("After Suite");
	}
	@BeforeTest
	void beforetest()
	{
		System.out.println("Before Test");
	}
	@AfterTest
	void aftertest()
	{
		System.out.println("After Test");
	}
	@BeforeClass
	void beforeclass()
	{
		System.out.println("Before Class2");
	}
	@AfterClass
	void afterclass()
	{
		System.out.println("After Class2");
	}
	@BeforeMethod
	void beforemethod()
	{
		System.out.println("Before Method2");
	}
	@AfterMethod
	void aftermethod()
	{
		System.out.println("After Method2");
	}
	@Parameters({"username"})
	@Test(groups="loginTest")//(enabled=false)
	void login(String u)
	{
		System.out.println("Website Login"+u);
	}
	@Test(dataProvider="getData")
	void logout(String username,String password)
	{
		System.out.println("Website Logout"+username+" "+password);
	}
	@DataProvider
	Object[][] getData()
	{
		Object[][]data=new Object[3][2];
		data[0][0]="user1";
		data[0][1]="pass1";
		data[1][0]="user2";
		data[1][1]="pass2";
		data[2][0]="user3";
		data[2][1]="pass3";
		return data;
	
	}
	
}
